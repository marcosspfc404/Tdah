// MainActivity Kotlin code
fun main() = println("App TDAH pronto!")